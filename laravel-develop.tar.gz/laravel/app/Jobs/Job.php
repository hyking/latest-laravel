<?php namespace App\Jobs;

abstract class Job
{
    //
}
